<html>

    <h1>A</h1>
    
    <?php echo html_entity_decode($inp);?>
</html>