<link rel="stylesheet" href="/js/libs/style.css">
<style type="text/css">
    .switch.ios
    {
        max-width: 260px;
    }
            body
            {
                background-color: whitesmoke;
            }
            .rem
            {
                color:red;
                cursor:pointer;
            }
            .colr
            {
             color: black;
            }
            #in
            {
                width: 470px;
                height: 100px;
                border: 1px solid;
                display: none;
                overflow: auto;
            }
            #in p
            {
                margin-bottom: 4px;
                margin-top: 2px;
            }
            form label
            {
                display: inline;
                margin-right: 5px;
                
           
            }
            .margin-left
            {
                margin-left: 10px;
            }
           .underline
           {
               text-decoration: underline;
               font-weight: bold;
           }
           li.field > span.under
           {
               display:block;
           }
          label.checkbox > span 
          {
              margin-right: 5px;
              cursor:pointer;
          }
          .picker select
          {
              cursor:pointer;
          }
          .field .checkbox.checked i
          {
           top:-2px;   
          }
    
    </style>
     <div class="container">
        <div class="row">
       
				<h2>Agregue Producto</h2>
                                <div class="row">
				<form action="<?php echo url_for("add_product");?>" method="POST" enctype="multipart/form-data"  data-form="validate" id="form1">
                                    <ul>
                                      
                                  <?php foreach($form as $k=>$sform)
                                    
                                  {
                                      ?>
                                       
                                            <?php
                                            if ($k=='_csrf_token'  || $k=='id')
                                            {
                                              
                                            }
                                            else
                                            {
                                                echo ' <li class="field">';
                                                     
                                                echo $sform->RenderRow();
                                                  echo '</li>';
                                            }
                                     
                                  }
                                    
                                  ?>
                                    

  <?php  echo $form->renderHiddenFields() ?>
                                   <div class="large btn default">
                                        <input type="submit" value="Save">
                                    </div>
                                        </div>
        </div>
     </div>
        <script type="text/javascript">
      $(document).ready(function ()
  {
      
      
      
          $("#producto_name").addClass("normal text input");
 
     $("#form1").submit(function ()
     {
       return true;
      });
 });
      
      </script>
      <script src="/js/libs/ui/gumby.checkbox.js"></script>
