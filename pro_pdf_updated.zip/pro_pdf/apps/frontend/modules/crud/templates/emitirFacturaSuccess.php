
        <div class="content">
             <div class="row">
                 
                 <form>
                     <label for="name cliente">Nombre</label>
                     <input type="text">
                     <label for="ruc">Ruc</label>
                     <input type="text">
                            <input type="submit" value="Ver pdf">
                     
                     
                 </form>
                 
                 
                 
                </div>
             </div>
        </div>
     

                
                
