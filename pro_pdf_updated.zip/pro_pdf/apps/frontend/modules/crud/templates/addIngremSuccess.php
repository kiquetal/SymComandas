        <div class="row">
            <h2>Ingrese Ingrediente</h2>
            <form method="POST" action="<?php echo url_for('addIm');?>" name="f1">
                   <?php  echo $form->renderHiddenFields() ?>
                <ul>
                   <?php foreach($form as $k=>$sform)
                                    
                                  {
                                      ?>
                                       
                                            <?php
                                            if ($k=='_csrf_token'  || $k=='id')
                                            {
                                              
                                            }
                                            else
                                            {
                                                echo ' <li class="field">';
                                            echo $sform->Render();
                                            
                                            }
                                     
                                  }
                                    
                                  ?>
                        
                    <li>
                        <div class="pretty medium primary btn">
                            <input type="submit" value="save"></input>
                        </div>
                        
                        
                    </li>
                
                </ul>
            </form>
        </div>
     
            
            
	
       <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="/js/libs/jquery-1.8.3.min.js"><\/script>')</script>
       <script type="text/javascript">
      $(document).ready(function ()
  {
          $("form input[type=checkbox]").each(function ()
  {
      var chek=this;
      
      var label=$(this).next().text();
     $(chek).wrap("<label class='checkbox'>"); 
     var p=$(chek).parent();
     $(p).append("<span></span>");
     $(p).append(label);
  });
  
         $("label.checkbox").next().remove();
         
           $(".checkbox_list").parent().prepend("<span><b><u>Productos Relacionados</u></b></span>")
         
     /*
      var n=noty({
  text: 'Do you want to continue?',
  buttons: [
    {addClass: 'btn btn-primary', text: 'Ok', onClick: function($noty) {

        // this = button element
        // $noty = $noty element

        $noty.close();
        noty({text: 'You clicked "Ok" button', type: 'success',layout:'top'});
      }
    },
    {addClass: 'btn btn-danger', text: 'Cancel', onClick: function($noty) {
        $noty.close();
        noty({text: 'You clicked "Cancel" button', type: 'error'});
      }
    }
  ]
});
*/


     $("#ingredientes_name").parent().prepend("<label class='inline'>Nombre</label>");
     $("#ingredientes_name").addClass("wide text input");
 });
      
      </script>

         <script src="/js/libs/gumby.js"> </script>
      <script src="/js/libs/gumby.min.js"></script>
      <script src="/js/plugins.js"></script>
      <script src="/js/main.js"></script>
      <script src="/js/libs/ui/gumby.checkbox.js"></script>
      
    