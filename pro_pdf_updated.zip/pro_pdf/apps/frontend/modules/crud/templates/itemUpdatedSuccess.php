
        <div class="content">
            <div class="row">
                <span class="medium oval btn default"> <a href="/">Menu Principal</a>
                    </span>
                     <span class="medium oval btn default"> <a href="<?php echo $dir;?>">Lista</a>
                    </span>
                   
            </div><br>
             <div class="row">
                 <div class="success label" style="height: auto">
                     <h3><?php  echo html_entity_decode($texto) ?></h3>
                    <ul>
                    <li>
                            <img src="<?php echo $img;?>">
                    
                    </li>

                    </ul>
                    
                </div>
                         
                   
             </div>
        </div>
     