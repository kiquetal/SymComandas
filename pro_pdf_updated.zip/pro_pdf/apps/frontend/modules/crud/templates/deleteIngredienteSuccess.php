
        <div class="container">
             <div class="row">
                 <div class="success label" style="width: 100%;height: 240px;">
                    <h3><Actualizacion exitosa></h3>
                   
                    <ul>
                        

                        <li>
                                       <?php echo $sf_user->getFlash("item_deleted"); ?>
                        </li><li>                            
            <?php echo $sf_user->getFlash("item_inactivo");?>
                        </li>
                    </ul>
                </div>
                
                
                
                
