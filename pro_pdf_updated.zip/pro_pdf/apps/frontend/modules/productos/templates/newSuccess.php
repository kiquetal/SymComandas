<h1>New Producto</h1>

<?php include_partial('form', array('form' => $form)) ?>
