<?php

/**
 * Ingredientes form.
 *
 * @package    comandas
 * @subpackage form
 * @author     Kiquetal
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class IngredientesForm extends BaseIngredientesForm
{
  public function configure()
  {
  }
}
